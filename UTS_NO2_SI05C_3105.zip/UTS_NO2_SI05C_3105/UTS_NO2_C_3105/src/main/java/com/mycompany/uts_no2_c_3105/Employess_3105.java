/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3105;

/**
 *
 * @author badnoby
 */
public class Employess_3105{
    
    protected String Nama_3071;
    protected String NIP_3071;
    protected float GajiPokok_3071;
    
    public void Tampil_3071(){
        System.out.println("Nama: " + Nama_3071);
        System.out.println("NIP: " + NIP_3071);
        System.out.println("Gaji Pokok: " + GajiPokok_3071);
    }
}
