/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3105;

/**
 *
 * @author badnoby
 */
public class SalariedEmployee_3105 extends Employess_3105 {
    public SalariedEmployee_3105(){
        
    }
    
    public void TampilData_3071(){
        System.out.println("Salaried Employee");
        Tampil_3071();
        System.out.println("Total Gaji: " + GajiPokok_3071);
    }
}
