/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3105;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author badnoby
 */
public class UTS_NO2_C_3105 {

    public static void main(String[] args) {
        SalariedEmployee_3105 se_3071 = new SalariedEmployee_3105();
        CommissionEmployee_3105 ce_3071 = new CommissionEmployee_3105();
        ProjectPlanner_3105 pp_3071 = new ProjectPlanner_3105();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3071.Nama_3071 = br.readLine();
            System.out.print("NIP: ");
            se_3071.NIP_3071 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3071.GajiPokok_3071 = Float.parseFloat(br.readLine());
            se_3071.TampilData_3071();
            
            System.out.print("Nama: ");
            ce_3071.Nama_3071 = br.readLine();
            System.out.print("NIP: ");
            ce_3071.NIP_3071 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3071.GajiPokok_3071 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3071.Komisi_3071 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3071.TotalPenjualan_3071 = Float.parseFloat(br.readLine());
            ce_3071.TotalGaji_3071();
            ce_3071.TampilData_3071();
            
            System.out.print("Nama: ");
            pp_3071.Nama_3071 = br.readLine();
            System.out.print("NIP: ");
            pp_3071.NIP_3071 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3071.GajiPokok_3071 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3071.Komisi_3071 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3071.TotalHslProyek_3071 = Float.parseFloat(br.readLine());
            pp_3071.TotalGaji_3071();
            pp_3071.TampilData_3071();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}
